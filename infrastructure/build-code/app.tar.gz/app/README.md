# Build Code

This is an amazing service for build code using CI/CD pipelines and containers.


## Usage

* Navigate to [http://127.0.0.1:3000](http://127.0.0.1:3000) for service

